#pragma once
#include "GameObject.h"

class Obstacle : public GameObject
{
private:
	Colour colour;
public:
	Obstacle(glm::vec3 position, Colour col = { 0, 0, 1 });
	~Obstacle();
	unsigned int setupDrawing(unsigned int listbase);
	void drawScene();
	void start();
	void update(int deltaTime);
	void collides(Collider* other);
};

