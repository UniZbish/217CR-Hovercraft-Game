#include "Hovercraft.h"
#include "CubeCollider.h"
#include "GameEngine.h"


Hovercraft::Hovercraft(glm::vec3 position, Colour col) : GameObject(position)
{
	this->colour = col;
	collider = new CubeCollider(&this->position, 3, 3, 3);
}


Hovercraft::~Hovercraft()
{
	delete Hovercraft::collider;
	Hovercraft::collider = NULL;
}

void Hovercraft::collides(Collider* other)
{
	if (GameEngine::debugMode)
	{
		std::cout << "Hovercraft collides!" << std::endl;
	}
}

unsigned int Hovercraft::setupDrawing(unsigned int listbase)
{
	this->base = ++listbase;
	glNewList(this->base, GL_COMPILE);
	//Hovercraft Body
	glPushMatrix();
	glTranslatef(0, 0, -0.4);
	glColor3f(1, 1, 1);
	glScalef(3, 1, 5);
	glutSolidCube(0.8); 
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, 0, -2.5);
	glRotatef(-90, 1, 0, 0);
	glColor3f(0, 1, 0);
	glScaled(0.1, 0.1, 1);
	gluCylinder(gluNewQuadric(), 5, 5, 1.5, 6, 6);
	glPopMatrix();
	glEndList();
	return this->base;
}

void Hovercraft::drawScene()
{
	glPushMatrix();
	glTranslatef(this->position.x, this->position.y, this->position.z);
	glRotatef(pitchAngle, 0.0, 0.0, 1.0);
	glRotatef(rotationAngle, 0.0, 1.0, 0.0);
	glCallList(this->base);
	glPopMatrix();

	if (GameEngine::debugMode)
	{
		Hovercraft::collider->Draw();
		glPushMatrix;
		glBegin(GL_LINES);
		glColor3f(1.0f, 1.0f, 0.0f);
		glVertex3f(this->position.x, this->position.y, this->position.z);
		glVertex3f(this->position.x - heading.x * 40, this->position.y - heading.y * 40, this->position.z - heading.z * 40);
		glEnd();
		glPopMatrix;

		glPushMatrix;
		glBegin(GL_LINES);
		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(this->position.x, this->position.y, this->position.z);
		glVertex3f(this->position.x - 40, this->position.y, this->position.z);
		glEnd();
		glPopMatrix;

		glPushMatrix;
		glBegin(GL_LINES);
		glColor3f(0.0f, 0.0f, 1.0f);
		glVertex3f(this->position.x, this->position.y, this->position.z);
		glVertex3f(this->position.x, this->position.y - 40, this->position.z);
		glEnd();
		glPopMatrix;

		glPushMatrix;
		glBegin(GL_LINES);
		glColor3f(0.0f, 1.0f, 0.0f);
		glVertex3f(this->position.x, this->position.y, this->position.z);
		glVertex3f(this->position.x, this->position.y, this->position.z - 40);
		glEnd();
		glPopMatrix;
	}
}

void Hovercraft::start()
{
}

void Hovercraft::update(int deltaTime)
{

	newVelocity = this->currentVelocity + ((this->acceleration * this->heading) * (deltaTime / 1000.0f));
	this->position += newVelocity * (deltaTime / 1000.0f);

	float moveStep = MOVE_SPEED * (deltaTime / 1000.0);
	float turningSpeed = TURNING_SPEED * (deltaTime / 1000.0);

	if (GameEngine::specialKeys[GLUT_KEY_UP])
	{
		acceleration -= (force / mass);
	}

	if (GameEngine::specialKeys[GLUT_KEY_DOWN])
	{
		acceleration += (force / mass);
		//this->position -= this->heading * moveStep;
	}

	if (acceleration > 1500 || acceleration < 1500)
	{
		if (acceleration > 1500)
		{
			acceleration = 1500;
		}
		else if (acceleration < -1500) 
		{
			acceleration = -1500;
		}
	}

	if ((GameEngine::specialKeys[GLUT_KEY_DOWN] == false && GameEngine::specialKeys[GLUT_KEY_UP] == false))
	{
		if (acceleration > 0)
		{
			acceleration -= drag;
		}
		else if (acceleration < 0)
		{
			acceleration += drag;
		}
		else
		{
			acceleration = 0;
		}
	}

std::cout << acceleration << std::endl;

	if (GameEngine::specialKeys[GLUT_KEY_PAGE_UP])
	{
		this->pitchAngle += turningSpeed;
	}

	if (GameEngine::specialKeys[GLUT_KEY_PAGE_DOWN])
	{
		this->pitchAngle -= turningSpeed;
	}

	if (GameEngine::specialKeys[GLUT_KEY_LEFT])
	{
		this->rotationAngle += turningSpeed;
	}

	if (GameEngine::specialKeys[GLUT_KEY_RIGHT])
	{
		this->rotationAngle -= turningSpeed;
	}

	this->heading = glm::rotate(this->startingHeading, glm::radians(rotationAngle), glm::vec3(0.0, 1.0, 0.0));
	this->heading = glm::rotate(this->heading, glm::radians(pitchAngle), glm::vec3(0.0, 0.0, 1.0));
}
