/////////////////////////////////          
// box.cpp
//
// This program draws a wire box.
//
// Sumanta Guha.
/////////////////////////////////

#include <iostream>

#ifdef __APPLE__
#  include <GL/glew.h>
#  include <GL/freeglut.h>
#  include <OpenGL/glext.h>
#else
#  include <GL/glew.h>
#  include <GL/freeglut.h>
//#  include <GL/glext.h>
#pragma comment(lib, "glew32.lib") 
#endif

#include "reader.h"
Reader obj;

using namespace std;

double xx;

// Drawing routine.
void drawScene(void)
{
	int i, id;
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0, 1.0, 1.0);
	glLoadIdentity();

	// Modeling transformations.
	glTranslatef(0.0, 0.0, -6.0);
	glRotatef(25, 1, 0, 0);
	glRotatef(45, 0, 1, 0);
	//glScalef(0.5, 0.5, 0.5);

		glBegin(GL_TRIANGLES);
			for (i = 0; i < obj.numFaces; i++)
			{
				id = obj.faces[i].id1;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
				id = obj.faces[i].id2;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
				id = obj.faces[i].id3;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
			}
		glEnd();

		///this is for four vertices polygon
		/*glBegin(GL_QUADS);
			for (i = 0; i < obj.numFaces; i++)
			{
				id = obj.faces[i].id1;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
				id = obj.faces[i].id2;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
				id = obj.faces[i].id3;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
				id = obj.faces[i].id4;
				glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
				glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
			}
		glEnd();*/


	glFlush();
}

// Initialization routine.
void setup(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	char filename[] = "cube.obj";
	obj.LoadModel(filename);
}

void animate() {

	/* update state variables */
	xx += .001;

	/* refresh screen */
	glutPostRedisplay();
}

// OpenGL window reshape routine.
void resize(int w, int h)
{
	glViewport(0, 0, w, h);

	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH);
	/* set up depth-buffering */
	glEnable(GL_DEPTH_TEST);

	/* turn on default lighting */
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40, 1, 4, 20);

	glMatrixMode(GL_MODELVIEW);
}

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 27:
		exit(0);
		break;
	default:
		break;
	}
}

// Main routine.
int main(int argc, char **argv)
{
	glutInit(&argc, argv);

	glutInitContextVersion(4, 3);
	glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("box.cpp");
	glutDisplayFunc(drawScene);
	glutReshapeFunc(resize);
	//glutIdleFunc(animate);
	glutKeyboardFunc(keyInput);

	glewExperimental = GL_TRUE;
	glewInit();

	setup();
	xx = 0.0;

	glutMainLoop();
}
