#include "GameEngine.h"

std::map<int, bool> GameEngine::specialKeys;
std::map<char, bool> GameEngine::keys;

bool GameEngine::debugMode;
std::vector<GameObject*> GameEngine::gameobjects;
GameObject* GameEngine::cameraFollow;
int GameEngine::oldTimeSinceStart;
int GameEngine::newTimeSinceStart;
/*std::map<int, bool>GameEngine::specialKeys;
std::map<char, bool>GameEngine::keys;*/
unsigned int GameEngine::base;

void GameEngine::initEngine(int argc, char ** argv, const char* windowTitle, bool debug, int width, int height)
{
	GameEngine::debugMode = debug;
	//GameEngine::debugMode = GameEngine::debugMode;

	//Init glut
	glutInit(&argc, argv);
	glutInitContextVersion(4, 3);
	glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(windowTitle);

	glewExperimental = GL_TRUE;
	glewInit();

	glutDisplayFunc(displayFunc);
	glutReshapeFunc(reshapeFunc);

	glutKeyboardFunc([](unsigned char key, int x, int y)
	{
		GameEngine::keys[key] = true;

		if (key == 27)
		{
			exit(0);
		}
	});

	glutKeyboardUpFunc([](unsigned char key, int x, int y)
	{
		GameEngine::keys[key] = false;
	});

	glutSpecialFunc([](int key, int x, int y)
	{
		GameEngine::specialKeys[key] = true;
	});

	glutSpecialUpFunc([](int key, int x, int y)
	{
		GameEngine::specialKeys[key] = false;
	});

	glutIdleFunc(updateGame);

}

void GameEngine::displayFunc()
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHT0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (cameraFollow != NULL)
	{
		float distance = 8;
		float yAm = 3;

		gluLookAt(cameraFollow->position.x + (cameraFollow->heading.x * distance), cameraFollow->position.y + (cameraFollow->heading.y * distance) + yAm, cameraFollow->position.z + (cameraFollow->heading.z * distance),
			cameraFollow->position.x, cameraFollow->position.y, cameraFollow->position.z, 0.0, 1.0, 0.0);
	}
	else
	{
		gluLookAt(0.0, 10.0, -5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	}

	for (std::vector<GameObject*>::size_type i = 0; i != gameobjects.size(); i++)
	{
		gameobjects[i]->drawScene();
	}
	glutSwapBuffers();
}

void GameEngine::reshapeFunc(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(60.0, (float)w / (float)h, 1.0, 500.0);
	glMatrixMode(GL_MODELVIEW);
};

void GameEngine::startEngine()
{
	std::cout << "Press escape to exit" << std::endl;

	glutMainLoop();
}

void GameEngine::addGameObject(GameObject* gameobject, bool camFollow)
{
	gameobjects.push_back(gameobject);

	if (camFollow)
	{
		cameraFollow = gameobject;
	}

	base = glGenLists(1);
	base = gameobject->setupDrawing(base);
	gameobject->start();
}

void GameEngine::updateGame()
{
	oldTimeSinceStart = newTimeSinceStart;
	newTimeSinceStart = glutGet(GLUT_ELAPSED_TIME);
	int deltaTime = newTimeSinceStart - oldTimeSinceStart;

	if (deltaTime == 0)
	{
		Sleep(1);
		newTimeSinceStart = glutGet(GLUT_ELAPSED_TIME);
		deltaTime = newTimeSinceStart - oldTimeSinceStart;
	}

	for (std::vector<GameObject*>::size_type i = 0 ; i != gameobjects.size(); i++)
	{
		if (!gameobjects[i]->active)
		{
			delete gameobjects[i];
			gameobjects.erase(gameobjects.begin() + i);
		}
	}

	for (std::vector<GameObject*>::size_type i = 0; i != gameobjects.size(); i ++)
	{
		gameobjects[i]->update(deltaTime);
	}

	for (std::vector<GameObject*>::size_type i = 0; i != gameobjects.size(); i++)
	{
		for (std::vector<GameObject*>::size_type j = i + 1; j != gameobjects.size(); j++) 
		{std::cout << "Testing " << i << " against " << j << std::endl;
			if (gameobjects[i]->collider != NULL)
			{
				
				if (gameobjects[i]->collider->collidesWith(gameobjects[j]->collider))
				{
					gameobjects[i]->collides(gameobjects[j]->collider);
					gameobjects[j]->collides(gameobjects[i]->collider);
				}
			}
		}
	}
	glutPostRedisplay();
}

void GameEngine::cleanup()
{
	for(auto it = gameobjects.begin(); it != gameobjects.end(); ++it)
	{
		delete *it;
	}
	gameobjects.clear();
}

