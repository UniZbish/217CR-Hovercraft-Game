#include "GameObject.h"
#include "CubeCollider.h"
#include "GameEngine.h"

/*std::map<int, bool> GameObject::specialKeys;
std::map<char, bool> GameObject::keys;*/


GameObject::GameObject(glm::vec3 pos){
	this->position = pos;
}


GameObject::~GameObject()
{
}

unsigned int GameObject::setupDrawing(unsigned int listbase)
{
	return 0;
}

void GameObject::drawScene()
{
	glPushMatrix();
	glTranslatef(this->position.x, this->position.y, this->position.z);
	glCallList(this->base);
	glPopMatrix();

	if (GameEngine::debugMode) 
	{
		this->collider->Draw();
	}
}

void GameObject::collides(Collider * other)
{
}
