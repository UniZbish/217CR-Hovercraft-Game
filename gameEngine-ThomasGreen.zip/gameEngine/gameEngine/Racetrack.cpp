#include "Racetrack.h"


Racetrack::Racetrack(glm::vec3 position, Colour col) : GameObject(position)
{
	this->colour = col;
}

Racetrack::~Racetrack()
{
}

unsigned int Racetrack::setupDrawing(unsigned int listbase)
{
	Reader obj;
	int i, id;
	char filename[] = "Trackblender.obj";
	obj.LoadModel(filename);

	glPushMatrix();
	this->base = ++listbase;
	glNewList(this->base, GL_COMPILE);
	glBegin(GL_QUADS);
	for (i = 0; i < obj.numFaces; i++)
	{
		id = obj.faces[i].id1;
		glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
		glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
		id = obj.faces[i].id2;
		glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
		glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
		id = obj.faces[i].id3;
		glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
		glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
		id = obj.faces[i].id4;
		glNormal3d(obj.normal[id].x, obj.normal[id].y, obj.normal[id].z);
		glVertex3d(obj.vertex[id].x, obj.vertex[id].y, obj.vertex[id].z);
	}
	glEnd();
	glPopMatrix();
	glEndList();
	return this->base;
}

void Racetrack::drawScene()
{
	glPushMatrix();
	glTranslatef(this->position.x, this->position.y, this->position.z);
	glCallList(this->base);
	glPopMatrix();
}

void Racetrack::start()
{
}

void Racetrack::update(int deltaTime)
{
}

