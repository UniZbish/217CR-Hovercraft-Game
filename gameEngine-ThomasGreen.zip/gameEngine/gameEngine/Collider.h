#pragma once
/* OPENGL_INCLUDES */
#ifndef OPENGL_INCLUDES
#define OPENGL_INCLUDES
#define _CRT_SECURE_NO_WARNINGS
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/glext.h>
#include <iostream>
#pragma comment(lib, "glew32.lib") 
#endif 
#include <glm/vec3.hpp>

class Collider
{
protected:
	glm::vec3* colliderCentre = NULL;
public:
	virtual bool collidesWith(Collider* other) = 0;
	virtual float minX() = 0;
	virtual float minY() = 0;
	virtual float maxX() = 0;
	virtual float maxY() = 0;
	virtual float minZ() = 0;
	virtual float maxZ() = 0;
	virtual void Draw() = 0;
};

