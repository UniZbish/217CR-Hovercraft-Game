#pragma once
/* OPENGL_INCLUDES */
#ifndef OPENGL_INCLUDES
#define OPENGL_INCLUDES
#define _CRT_SECURE_NO_WARNINGS
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/glext.h>
#include <iostream>
#pragma comment(lib, "glew32.lib") 
#endif 

#include <glm/glm.hpp>
#include <iostream>
#include <map>
#include "Collider.h"


struct Colour
{
	float r, g, b;
};

class GameObject
{
protected:
	unsigned int base;
public:
	Collider* collider = NULL;
	bool active = true;
	static bool debugMode;
	/*static std::map<int, bool>specialKeys;
	static std::map<char, bool>keys;*/
	glm::vec3 heading = glm::vec3(0.0, 0.0, -1.0);
	glm::vec3 position;
	
	GameObject(glm::vec3 position);
	~GameObject();

	virtual unsigned int setupDrawing(unsigned int listbase);
	virtual void drawScene();
	virtual void start() = 0;
	virtual void update(int deltaTime) = 0;
	virtual void collides(Collider* other);
};

