#pragma once
#include "Collider.h"

class CubeCollider : public Collider
{
private:
public:
	float length = 0.0, width = 0.0, height = 0.0;

	CubeCollider(glm::vec3 * centre, float cubeWidth, float cubeHeight, float cubeLength);
	~CubeCollider();

	float minX();
	float minY();
	float minZ();
	float maxX();
	float maxY();
	float maxZ();
	bool collidesWith(Collider * other);
	void Draw();
};