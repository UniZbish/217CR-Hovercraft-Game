#pragma once
#include "GameObject.h"
#include "reader.h"

class Racetrack : public GameObject
{
private:
	Colour colour;
public:
	Racetrack(glm::vec3 position, Colour col = { 0, 1, 0 });
	~Racetrack();
	unsigned int setupDrawing(unsigned int listbase);
	void drawScene();
	void start();
	void update(int deltaTime);
};