#pragma once
#include "GameObject.h"
#include <glm/gtx/rotate_vector.hpp>

#define TURNING_SPEED 90.0
#define MOVE_SPEED 40.0

class Hovercraft : public GameObject
{
private:
	Colour colour;
public:
	glm::vec3 startingHeading = heading;
	float rotationAngle, pitchAngle = 0.0;
	float force = 10.0f, drag = 30.0f, acceleration;
	glm::vec3 currentVelocity, newVelocity;
	float mass = 1.0f;
	//collider* collider = NULL;

	Hovercraft(glm::vec3 position, Colour col = {0, 1, 0});
	~Hovercraft();

	unsigned int setupDrawing(unsigned int listbase);
	void drawScene();
	void start();
	void update(int deltaTime);
	void collides(Collider* other);
};

