#include "Obstacle.h"
#include "CubeCollider.h"
#include "GameEngine.h"



Obstacle::Obstacle(glm::vec3 position, Colour col) : GameObject(position)
{
	this->colour = col;
	Obstacle::collider = new CubeCollider(&this->position, 20, 20, 20);
}

Obstacle::~Obstacle()
{
	delete Obstacle::collider;
	Obstacle::collider = NULL;

}
unsigned int Obstacle::setupDrawing(unsigned int listbase)
{
	this->base = ++listbase;
	//glNewList(this->base, GL_COMPILE);
	glNewList(this->base, GL_COMPILE);
	glPushMatrix();
	glColor3d(0.55, 0.27, 0.07);
	glutSolidSphere(10.0, 40, 40);
	glPopMatrix();
	glEndList();
	return this->base;
}

void Obstacle::drawScene()
{
	//obstacle
	Obstacle::collider->Draw();
	glPushMatrix();
	glTranslatef(this->position.x, this->position.y, this->position.z);
	glCallList(this->base);
	glPopMatrix();
}

void Obstacle::start()
{
}

void Obstacle::update(int deltaTime)
{
}

void Obstacle::collides(Collider* other)
{
	if (GameEngine::debugMode)
	{
		std::cout << "Obstacle collides, obstacle will be removed!" << std::endl;
	}
	this->active = false;
}